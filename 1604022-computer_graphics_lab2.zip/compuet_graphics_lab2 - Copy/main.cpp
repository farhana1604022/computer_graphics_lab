#include<bits/stdc++.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include<windows.h>
using namespace std;
float x,y,x2,y2,dx,dy,m;
void display(){
    glColor3f (0.0, 1.0, 0.0);
    glBegin(GL_POINTS);

    if(m<1){
        while(x<=x2 && y<=y2){
            x++;
            y=y+m;
            glVertex3f(x/100,y/100,0.0);
            cout<<x<<" "<<round(y)<<endl;
        }
    }
    else if(m>1){
        while(x<=x2 && y<=y2){
            x=x+(1/m);
            y++;
            glVertex3f(x/100,y/100,0.0);
            cout<<round(x)<<" "<<y<<endl;
        }
    }
    glEnd();



glFlush ();
}
void init (void)
{
glClearColor (0.7, 0.7, 0.7, 0.7);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);

}
int main(int argc, char** argv){
    cout<<"Enter the value of x, y, x2, y2:";
    cin>>x>>y>>x2>>y2;
    dx=x2-x;
    dy=y2-y;
    m=(float)dy/dx;
    glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (500, 500);
glutInitWindowPosition (100, 100);
glutCreateWindow ("DDA Line Drawing Algorithm");
init ();
glutDisplayFunc(display);
glutMainLoop();
    return 0;
}
